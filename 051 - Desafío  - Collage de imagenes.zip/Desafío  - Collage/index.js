const express = require("express");
const app = express();
require("dotenv").config();
const expressFileUpload = require("express-fileupload");
const fs= require("fs");


app.listen(process.env.PORT, () => {
  console.log(`Servidor en puerto ${process.env.PORT}`);
});


//1. Integrar express-fileupload a Express.
//2. Definir que el límite para la carga de imágenes es de 5MB.
app.use(
  expressFileUpload({
    limits: { fileSize: 5_000_000 },
    abortOnLimit: true,
    responseOnLimit: "El peso del archivo supera el límite permitido", //3. Responder con un mensaje indicando que se sobrepasó el límite especificado.
  })
);

//4. Crear una ruta POST /imagen
app.post("/imagen", (request, response) => {
  const { target_file } = request.files;
  console.log(request.files)
  const { nombre, posicion } = request.body;
  const name = `${nombre}.${posicion}`;

  target_file.mv(`${__dirname}/public/imgs/imagen-${posicion}.jpg`, (error) => {
    if (error) {
      return response.status(500).send("ERROR: imposible cargar la imagen");
    }
    response.send("Imagen cargada con éxito");
  });
});

app.use(express.static("public"));

app.get("/", (request, response) => {
    response.sendFile(__dirname + "/public/formulario.html" );
});

app.get("/collage", (request, response) => {
    response.sendFile(__dirname + "/public/collage.html" );
});

//5. Crear una ruta GET /deleteImg/:nombre
app.get("/deleteImg/:nombre", (request, response) => {
  const { nombre } = request.params;

  fs.unlink(`${__dirname}/public/imgs/${nombre}`, (error) => {
    if (error) {
      return response.status(500).send("ERROR: imposible eliminar imagen");
    }

    response.send(`Imagen ${nombre} eliminada`);
  });
});
