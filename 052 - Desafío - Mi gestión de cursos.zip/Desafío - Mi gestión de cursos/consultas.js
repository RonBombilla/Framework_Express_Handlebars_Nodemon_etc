const { Pool } = require('pg');

const pool = new Pool({
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: '6651',
    database: 'cursos',
});

const nuevoCurso = async(nombre, nivel, fecha, duracion)=>{
    try {
        const resultado = await pool.query(
            `INSERT INTO cursos (nombre, nivel, fecha, duracion) VALUES ('${nombre}', ${nivel}, '${fecha}', ${duracion}) RETURNING *;`
            );
        return resultado.rows;
    } catch (error) {
        return error;
    }
}

const getCursos = async()=>{
    try {
        const resultado = await pool.query(
            `SELECT * FROM cursos;`
            );
        return resultado.rows;
    } catch (error) {
        return error;
    }
};

const updateCurso = async(id, nombre, nivelTecnico, fechaInicio, duracion)=>{
    try {
        const resultado = await pool.query(
            `UPDATE cursos SET nombre='${nombre}', nivel=${nivelTecnico}, fecha='${fechaInicio}', duracion=${duracion} WHERE id=${id} RETURNING *;`
            );
            console.log(resultado);
        return resultado.rows[0];
    } catch (error) {
        return error;
    }
}

const deleteCurso = async(id)=>{
    try {
        const resultado = await pool.query(
            `DELETE FROM cursos WHERE id=${id}`
            );
    } catch (error) {
        return error;
    }
}
module.exports = {
    nuevoCurso,
    getCursos,
    updateCurso,
    deleteCurso,
};