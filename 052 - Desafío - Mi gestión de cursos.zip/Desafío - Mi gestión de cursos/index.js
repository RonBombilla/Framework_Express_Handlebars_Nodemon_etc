const express = require('express');
const app = express();
require('dotenv').config();
const bodyParser = require('body-parser');
const port = process.env.PORT;

const { nuevoCurso, getCursos, updateCurso, deleteCurso } = require('./consultas');

app.listen(port, ()=>{
    console.log(`Server running on http://localhost:${port} and process ID: ${process.pid}`)
});

app.use(bodyParser.urlencoded({ extended:false}));
app.use(bodyParser.json());

//Mostrar Front
app.use(express.static('/'));
app.get('/', (request, response)=>{
    response.sendFile(`${__dirname}/index.html`);
});

//1. Crear una ruta ​POST /curso ​que reciba un payload desde el cliente con los datos de un nuevo curso y los ingrese a la tabla​ cursos​.
app.post('/curso', async(request, response)=>{
   const { nombre, nivelTecnico, fechaInicio, duracion } = request.body;
   const resultado = await nuevoCurso(nombre, nivelTecnico, fechaInicio, duracion);
   response.send(resultado);
});

//2. Crear una ruta ​GET /cursos ​que consulte y devuelva los registros almacenados en la tabla ​cursos​.
app.get('/cursos', async(request, response)=>{
    const respuesta = await getCursos();
    response.send(respuesta);
});

//3. Crear una ruta ​PUT /curso ​que reciba un payload desde el cliente con los datos de un curso ya existente y actualice su registro en la tabla ​cursos​.
app.put('/curso', async(request, response)=>{
    const { id, nombre, nivelTecnico, fechaInicio, duracion } = request.body;
    console.log(id, nombre, nivelTecnico, fechaInicio, duracion);
    const respuesta = await updateCurso(id, nombre, nivelTecnico, fechaInicio, duracion);
    response.send(respuesta);
});

//4. Crear una ruta ​DELETE /cursos ​que reciba el id de un curso como parámetro de la ruta y elimine el registro relacionado en la tabla ​cursos.
app.delete('/curso/:id', async(request, response)=>{
    const { id } = request.params;
    const resultado = await deleteCurso(id);
    response.send(resultado);
});