exports.results = [
  {
    email: 'who@fbi.com',
    password: 'me',
  },
  {
    email: 'where@fbi.com',
    password: 'there',
  },
  {
    email: 'how@fbi.com',
    password: 'exactly',
  },
]
