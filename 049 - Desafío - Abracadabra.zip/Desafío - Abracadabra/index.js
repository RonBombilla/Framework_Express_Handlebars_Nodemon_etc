const express = require('express');
const app = express();
const fs = require('fs');

let name;
//Crear un servidor con Express en el puerto 3000
app.listen(3000,() =>{
    console.log('Server on running port 3000...' + process.pid);
});

//Definir la carpeta “assets” como carpeta pública del servidor
app.use(express.static("Public/assets"));

/*Crear en el servidor un arreglo de nombres y devolverlo en formato JSON a través de 
la ruta /abracadabra/usuarios.*/
app.get('/abracadabra/usuarios',(req, res) =>{
    res.sendFile(__dirname + '/usuarios.json');
})

/*Crear un middleware con la ruta /abracadabra/juego/:usuario para validar que el
usuario recibido como parámetro “usuario” existe en el arreglo de nombres creado
en el servidor*/
app.use('/abracadabra/juego/:usuario',(req, res ,next)=>{
    const usuario1 = req.params.usuario;
    const x = JSON.parse(fs.readFileSync('./usuarios.json'));
    x.usuarios.find(e => { if(e == usuario1) name = e;});
    !name
     ? res.send(`<img src="/who.jpeg" width=500px>`)//? res.sendFile(__dirname + '/Public/assets/who.jpeg') 
     : next();
});

app.get('/abracadabra/juego/:usuario', (req, res) => {
    res.send('<p style = "color:green"> Usuario autentificado! </p>')
});

/*Crear una ruta /abracadabra/conejo/:n que valide si el parámetro “n” coincide con el
número generado de forma aleatoria*/
app.get('/abracadabra/conejo/:n',(req, res) => {
    const random = Math.floor(Math.random() * (5 - 1)) + 1;
    const number = req.params.n;
    random == number
        ? res.sendFile(__dirname + '/Public/assets/conejito.jpg')
        : res.sendFile(__dirname + '/Public/assets/voldemort.jpg');
});

//ejecuto el archivo index.html
app.get('/',(req, res) => {
    res.sendFile(__dirname + '/Public/index.html');
});


/* Crear una ruta genérica que devuelva un mensaje diciendo “Esta página no existe...”
al consultar una ruta que no esté definida en el servidor*/
app.get('*',(req, res)=>{
    res.send('<p style = "color:red"> Nop, esta página no existe... </p>');
});