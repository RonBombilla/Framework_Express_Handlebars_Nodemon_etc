const express = require('express');
const app = express();
const exphbs = require('express-handlebars');
const fs = require('fs');

app.listen(3000, () => {
    console.log('Servidor levantado en el puerto 3000... '+ process.pid);
});

app.set("view engine","handlebars");

app.use('/imgs',express.static(`${__dirname}/Public/img`));

app.use('/bootstrap',express.static(`${__dirname}/node_modules/bootstrap/dist`));
app.use('/jquery',express.static(`${__dirname}/node_modules/jquery/dist`));

app.engine(
    "handlebars",
    exphbs({
        layoutsDir: `${__dirname}/views`,
        partialsDir: `${__dirname}/views/partials`
    })
);

app.get("/",(req, res) => {
    res.render("main", { layout: 'main',
        //usuario : " ",
        dashboard: ["banana","cebollas","lechuga","papas","pimenton","tomate"] });
});

app.get('/:verduras',(req, res)=>{
    const { verduras } = req.params;
    res.render("main",{
        layout: "main",
        producto: ["banana","cebollas","lechuga","papas","pimenton","tomate"],
        verduras: verduras
    });
});